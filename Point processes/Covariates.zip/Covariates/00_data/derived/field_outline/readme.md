Derived data sets will be created here. 

 - SPgfo.RDS a spatial fields data frame giving the Groningen gas field outline. Useful for subsetting earthquakes and making plots.
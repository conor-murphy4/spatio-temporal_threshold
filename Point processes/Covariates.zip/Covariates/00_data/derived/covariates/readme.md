Derived data sets will be created here. 

 - strainThicknessRough.csv : Gridded strain thickness calculated as the product of linear compaction and topographic gradient. 
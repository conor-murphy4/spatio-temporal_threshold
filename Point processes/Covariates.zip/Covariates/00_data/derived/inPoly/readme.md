Derived data sets will be created here. 

 - inPolyMat.RDS : Logical matrix showing covariate inclusion within gas Field 
 - inPolyVec.RDS : Logical vector showing covariate value is within gas field